<?php
/**
 * Admin Sample Data Page
 *
 * Provides UI for installing and managing sample crystal data
 *
 * @package Roihin_Crystal_Manager
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register admin menu
 */
add_action('admin_menu', 'roihin_crystal_add_sample_data_menu');

function roihin_crystal_add_sample_data_menu() {
    add_submenu_page(
        'edit.php?post_type=crystal',
        __('Sample Data', 'roihin-crystal'),
        __('Sample Data', 'roihin-crystal'),
        'manage_options',
        'crystal-sample-data',
        'roihin_crystal_sample_data_page'
    );
}

/**
 * Sample data admin page
 */
function roihin_crystal_sample_data_page() {
    // Check permissions
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'roihin-crystal'));
    }

    $is_installed = Roihin_Crystal_Sample_Data_Installer::is_installed();
    $installed_count = Roihin_Crystal_Sample_Data_Installer::get_installed_count();
    $unsplash_api_key = get_option('roihin_crystal_unsplash_api_key', '');
    $api_key_configured = !empty($unsplash_api_key);
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

        <div class="notice notice-info">
            <p>
                <strong><?php _e('About Sample Data:', 'roihin-crystal'); ?></strong>
                <?php _e('Import pre-configured sample crystal products to explore all plugin features and test the frontend catalog pages.', 'roihin-crystal'); ?>
            </p>
            <p>
                <?php _e('Sample data includes 19 diverse crystals covering all 12 colors, 5 energy properties, 12 zodiac signs, and 4 elements.', 'roihin-crystal'); ?>
            </p>
        </div>

        <!-- Messages container -->
        <div id="sample-data-message" style="display: none;"></div>
        <div id="api-key-message" style="display: none;"></div>

        <!-- Unsplash API Configuration -->
        <div class="card" style="max-width: 600px; margin: 20px 0;">
            <h2><?php _e('Unsplash API Configuration', 'roihin-crystal'); ?></h2>
            <p class="description">
                <?php _e('Sample data uses Unsplash to fetch high-quality crystal images. Enter your Unsplash Access Key below.', 'roihin-crystal'); ?>
                <a href="https://unsplash.com/developers" target="_blank"><?php _e('Get your free API key', 'roihin-crystal'); ?></a>
            </p>

            <table class="form-table" style="margin-top: 15px;">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="unsplash-api-key"><?php _e('Access Key:', 'roihin-crystal'); ?></label>
                        </th>
                        <td>
                            <input
                                type="text"
                                id="unsplash-api-key"
                                name="unsplash_api_key"
                                value="<?php echo esc_attr($unsplash_api_key); ?>"
                                class="regular-text"
                                placeholder="<?php _e('Enter your Unsplash Access Key', 'roihin-crystal'); ?>"
                            />
                            <p class="description">
                                <?php _e('Your API key is stored securely and only used to fetch images during sample data installation.', 'roihin-crystal'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label><?php _e('Status:', 'roihin-crystal'); ?></label>
                        </th>
                        <td id="api-key-status">
                            <?php if ($api_key_configured): ?>
                                <span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span>
                                <span style="color: #46b450;"><?php _e('Configured', 'roihin-crystal'); ?></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-warning" style="color: #dba617;"></span>
                                <span style="color: #dba617;"><?php _e('Not Configured', 'roihin-crystal'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <p class="submit" style="padding: 0; margin-top: 10px;">
                <button type="button" id="save-api-key" class="button button-primary">
                    <?php _e('Save API Key', 'roihin-crystal'); ?>
                </button>
                <?php if ($api_key_configured): ?>
                    <button type="button" id="clear-api-key" class="button button-secondary" style="margin-left: 10px;">
                        <?php _e('Clear API Key', 'roihin-crystal'); ?>
                    </button>
                <?php endif; ?>
            </p>
        </div>

        <!-- Status Box -->
        <div class="card" style="max-width: 600px; margin: 20px 0;">
            <h2><?php _e('Installation Status', 'roihin-crystal'); ?></h2>
            <table class="widefat" style="margin-top: 10px;">
                <tbody>
                    <tr>
                        <td style="width: 200px;"><strong><?php _e('Status:', 'roihin-crystal'); ?></strong></td>
                        <td id="installation-status">
                            <?php if ($is_installed): ?>
                                <span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span>
                                <span style="color: #46b450;"><?php _e('Installed', 'roihin-crystal'); ?></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-dismiss" style="color: #dc3232;"></span>
                                <span style="color: #dc3232;"><?php _e('Not Installed', 'roihin-crystal'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('Crystal Products:', 'roihin-crystal'); ?></strong></td>
                        <td id="installation-count">
                            <?php echo esc_html($installed_count); ?>
                            <?php if ($installed_count > 0): ?>
                                <a href="<?php echo admin_url('edit.php?post_type=crystal&crystal_category=sample-data'); ?>" class="button button-small" style="margin-left: 10px;">
                                    <?php _e('View All', 'roihin-crystal'); ?>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Actions -->
        <div class="card" style="max-width: 600px;">
            <h2><?php _e('Actions', 'roihin-crystal'); ?></h2>

            <?php if (!$is_installed): ?>
                <p>
                    <button type="button" id="install-sample-data" class="button button-primary button-hero">
                        <span class="dashicons dashicons-download" style="margin-top: 4px;"></span>
                        <?php _e('Install Sample Data', 'roihin-crystal'); ?>
                    </button>
                </p>
                <p class="description">
                    <?php _e('This will create 19 sample crystal products with images, descriptions, and full metadata.', 'roihin-crystal'); ?>
                </p>
            <?php else: ?>
                <p>
                    <button type="button" id="uninstall-sample-data" class="button button-secondary">
                        <span class="dashicons dashicons-trash" style="margin-top: 4px;"></span>
                        <?php _e('Remove Sample Data', 'roihin-crystal'); ?>
                    </button>
                </p>
                <p class="description" style="color: #d63638;">
                    <?php _e('Warning: This will permanently delete all sample crystal products and their images.', 'roihin-crystal'); ?>
                </p>
            <?php endif; ?>

            <!-- Progress bar -->
            <div id="progress-container" style="display: none; margin-top: 20px;">
                <p><strong id="progress-text"><?php _e('Processing...', 'roihin-crystal'); ?></strong></p>
                <div style="background: #f0f0f1; border-radius: 3px; height: 30px; overflow: hidden;">
                    <div id="progress-bar" style="background: #2271b1; height: 100%; width: 0%; transition: width 0.3s;"></div>
                </div>
            </div>
        </div>

        <!-- Sample Data Preview -->
        <div class="card" style="margin-top: 20px; max-width: 100%;">
            <h2><?php _e('Sample Data Preview', 'roihin-crystal'); ?></h2>
            <p><?php _e('The following crystal products will be created:', 'roihin-crystal'); ?></p>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 30px;">#</th>
                        <th><?php _e('Crystal Name (EN)', 'roihin-crystal'); ?></th>
                        <th><?php _e('Crystal Name (TH)', 'roihin-crystal'); ?></th>
                        <th><?php _e('Colors', 'roihin-crystal'); ?></th>
                        <th><?php _e('Energy Properties', 'roihin-crystal'); ?></th>
                        <th><?php _e('Elements', 'roihin-crystal'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Load sample data for preview
                    $sample_data_path = ROIHIN_CRYSTAL_PLUGIN_DIR . 'data/sample-crystals.json';
                    if (file_exists($sample_data_path)) {
                        $json_content = file_get_contents($sample_data_path);
                        $crystals = json_decode($json_content, true);

                        if (is_array($crystals)) {
                            foreach ($crystals as $index => $crystal) {
                                ?>
                                <tr>
                                    <td><?php echo esc_html($index + 1); ?></td>
                                    <td><strong><?php echo esc_html($crystal['crystal_name_en'] ?? '-'); ?></strong></td>
                                    <td><?php echo esc_html($crystal['crystal_name_th'] ?? '-'); ?></td>
                                    <td>
                                        <?php
                                        if (!empty($crystal['color_filter'])) {
                                            echo esc_html(implode(', ', array_slice($crystal['color_filter'], 0, 3)));
                                            if (count($crystal['color_filter']) > 3) {
                                                echo ' +' . (count($crystal['color_filter']) - 3);
                                            }
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if (!empty($crystal['energy_properties'])) {
                                            echo esc_html(count($crystal['energy_properties'])) . ' ' . __('properties', 'roihin-crystal');
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if (!empty($crystal['element_type'])) {
                                            echo esc_html(implode(', ', $crystal['element_type']));
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Help Box -->
        <div class="card" style="margin-top: 20px; max-width: 800px; background: #f8f9fa;">
            <h2><?php _e('Help & Information', 'roihin-crystal'); ?></h2>
            <ul style="list-style: disc; padding-left: 20px;">
                <li><strong><?php _e('API Key Required:', 'roihin-crystal'); ?></strong> <?php _e('You must configure your Unsplash API key before installing sample data. Get a free API key at', 'roihin-crystal'); ?> <a href="https://unsplash.com/developers" target="_blank">unsplash.com/developers</a>.</li>
                <li><strong><?php _e('Safe to Install:', 'roihin-crystal'); ?></strong> <?php _e('Sample data is tagged with a special category for easy identification and removal.', 'roihin-crystal'); ?></li>
                <li><strong><?php _e('Complete Data:', 'roihin-crystal'); ?></strong> <?php _e('Each crystal includes bilingual names, descriptions, properties, filters, and high-quality images from Unsplash.', 'roihin-crystal'); ?></li>
                <li><strong><?php _e('Filter Coverage:', 'roihin-crystal'); ?></strong> <?php _e('Sample data covers all filter options to test the frontend catalog pages.', 'roihin-crystal'); ?></li>
                <li><strong><?php _e('Images:', 'roihin-crystal'); ?></strong> <?php _e('Crystal images will be downloaded from Unsplash and added to your media library (3 images per crystal: 1 main + 2 gallery).', 'roihin-crystal'); ?></li>
                <li><strong><?php _e('Rate Limits:', 'roihin-crystal'); ?></strong> <?php _e('Unsplash demo keys have 50 requests/hour. For 19 crystals, you need 57 requests. Consider getting a production key (5000/hour) if needed.', 'roihin-crystal'); ?></li>
                <li><strong><?php _e('Related Products:', 'roihin-crystal'); ?></strong> <?php _e('No related products are set - you can add them manually if needed.', 'roihin-crystal'); ?></li>
                <li><strong><?php _e('Clean Removal:', 'roihin-crystal'); ?></strong> <?php _e('Uninstalling removes all sample posts and images without affecting your real data.', 'roihin-crystal'); ?></li>
            </ul>
        </div>
    </div>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        var nonce = '<?php echo wp_create_nonce('roihin_crystal_sample_data'); ?>';

        // Show message
        function showMessage(message, type) {
            var $messageDiv = $('#sample-data-message');
            $messageDiv.removeClass('notice-success notice-error notice-warning notice-info');
            $messageDiv.addClass('notice is-dismissible notice-' + type);
            $messageDiv.html('<p>' + message + '</p>');
            $messageDiv.show();

            // Scroll to message
            $('html, body').animate({
                scrollTop: $messageDiv.offset().top - 50
            }, 500);
        }

        // Show API key message
        function showApiKeyMessage(message, type) {
            var $messageDiv = $('#api-key-message');
            $messageDiv.removeClass('notice-success notice-error notice-warning notice-info');
            $messageDiv.addClass('notice is-dismissible notice-' + type);
            $messageDiv.html('<p>' + message + '</p>');
            $messageDiv.show();

            // Scroll to message
            $('html, body').animate({
                scrollTop: $messageDiv.offset().top - 50
            }, 500);

            // Auto-hide success messages after 3 seconds
            if (type === 'success') {
                setTimeout(function() {
                    $messageDiv.fadeOut();
                }, 3000);
            }
        }

        // Update API key status
        function updateApiKeyStatus(configured) {
            var $status = $('#api-key-status');

            if (configured) {
                $status.html('<span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span>' +
                    '<span style="color: #46b450;"><?php _e('Configured', 'roihin-crystal'); ?></span>');

                // Show clear button if not exists
                if ($('#clear-api-key').length === 0) {
                    $('#save-api-key').after('<button type="button" id="clear-api-key" class="button button-secondary" style="margin-left: 10px;"><?php _e('Clear API Key', 'roihin-crystal'); ?></button>');
                    attachClearHandler();
                }
            } else {
                $status.html('<span class="dashicons dashicons-warning" style="color: #dba617;"></span>' +
                    '<span style="color: #dba617;"><?php _e('Not Configured', 'roihin-crystal'); ?></span>');

                // Hide clear button
                $('#clear-api-key').remove();
            }
        }

        // Save API Key
        $('#save-api-key').on('click', function() {
            var apiKey = $('#unsplash-api-key').val().trim();

            if (apiKey === '') {
                showApiKeyMessage('<?php _e('Please enter an API key.', 'roihin-crystal'); ?>', 'warning');
                return;
            }

            var $button = $(this);
            $button.prop('disabled', true).text('<?php _e('Saving...', 'roihin-crystal'); ?>');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'roihin_crystal_save_unsplash_api_key',
                    nonce: nonce,
                    api_key: apiKey
                },
                success: function(response) {
                    $button.prop('disabled', false).text('<?php _e('Save API Key', 'roihin-crystal'); ?>');

                    if (response.success) {
                        showApiKeyMessage(response.data.message, 'success');
                        updateApiKeyStatus(true);
                    } else {
                        showApiKeyMessage(response.data.message, 'error');
                    }
                },
                error: function() {
                    $button.prop('disabled', false).text('<?php _e('Save API Key', 'roihin-crystal'); ?>');
                    showApiKeyMessage('<?php _e('An error occurred. Please try again.', 'roihin-crystal'); ?>', 'error');
                }
            });
        });

        // Clear API Key handler
        function attachClearHandler() {
            $('#clear-api-key').off('click').on('click', function() {
                if (!confirm('<?php _e('Are you sure you want to clear the API key?', 'roihin-crystal'); ?>')) {
                    return;
                }

                var $button = $(this);
                $button.prop('disabled', true);

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'roihin_crystal_clear_unsplash_api_key',
                        nonce: nonce
                    },
                    success: function(response) {
                        $button.prop('disabled', false);

                        if (response.success) {
                            $('#unsplash-api-key').val('');
                            showApiKeyMessage(response.data.message, 'success');
                            updateApiKeyStatus(false);
                        } else {
                            showApiKeyMessage(response.data.message, 'error');
                        }
                    },
                    error: function() {
                        $button.prop('disabled', false);
                        showApiKeyMessage('<?php _e('An error occurred. Please try again.', 'roihin-crystal'); ?>', 'error');
                    }
                });
            });
        }

        // Attach clear handler on page load
        attachClearHandler();

        // Show progress
        function showProgress(text, percent) {
            $('#progress-container').show();
            $('#progress-text').text(text);
            $('#progress-bar').css('width', percent + '%');
        }

        // Hide progress
        function hideProgress() {
            $('#progress-container').hide();
            $('#progress-bar').css('width', '0%');
        }

        // Update status display
        function updateStatus(installed, count) {
            var $status = $('#installation-status');
            var $count = $('#installation-count');

            if (installed) {
                $status.html('<span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span>' +
                    '<span style="color: #46b450;"><?php _e('Installed', 'roihin-crystal'); ?></span>');
                $count.html(count + ' <a href="<?php echo admin_url('edit.php?post_type=crystal&crystal_category=sample-data'); ?>" class="button button-small" style="margin-left: 10px;"><?php _e('View All', 'roihin-crystal'); ?></a>');

                // Switch buttons
                $('#install-sample-data').parent().parent().hide();
                $('#uninstall-sample-data').parent().parent().show();
            } else {
                $status.html('<span class="dashicons dashicons-dismiss" style="color: #dc3232;"></span>' +
                    '<span style="color: #dc3232;"><?php _e('Not Installed', 'roihin-crystal'); ?></span>');
                $count.text('0');

                // Switch buttons
                $('#install-sample-data').parent().parent().show();
                $('#uninstall-sample-data').parent().parent().hide();
            }
        }

        // Install sample data
        $('#install-sample-data').on('click', function() {
            // Check if API key is configured
            var apiKey = $('#unsplash-api-key').val().trim();
            if (apiKey === '') {
                showMessage('<?php _e('Please configure your Unsplash API key before installing sample data.', 'roihin-crystal'); ?>', 'warning');
                // Scroll to API key input
                $('html, body').animate({
                    scrollTop: $('#unsplash-api-key').offset().top - 100
                }, 500);
                $('#unsplash-api-key').focus();
                return;
            }

            if (!confirm('<?php _e('Are you sure you want to install sample data? This will create 19 crystal products with images from Unsplash.', 'roihin-crystal'); ?>')) {
                return;
            }

            var $button = $(this);
            $button.prop('disabled', true);

            showProgress('<?php _e('Installing sample data...', 'roihin-crystal'); ?>', 10);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'roihin_crystal_install_sample_data',
                    nonce: nonce
                },
                success: function(response) {
                    hideProgress();
                    $button.prop('disabled', false);

                    if (response.success) {
                        showMessage(response.data.message, 'success');
                        updateStatus(true, response.data.count);
                    } else {
                        showMessage(response.data.message, 'error');
                    }
                },
                error: function() {
                    hideProgress();
                    $button.prop('disabled', false);
                    showMessage('<?php _e('An error occurred. Please try again.', 'roihin-crystal'); ?>', 'error');
                }
            });
        });

        // Uninstall sample data
        $('#uninstall-sample-data').on('click', function() {
            if (!confirm('<?php _e('Are you sure you want to remove all sample data? This action cannot be undone.', 'roihin-crystal'); ?>')) {
                return;
            }

            var $button = $(this);
            $button.prop('disabled', true);

            showProgress('<?php _e('Removing sample data...', 'roihin-crystal'); ?>', 10);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'roihin_crystal_uninstall_sample_data',
                    nonce: nonce
                },
                success: function(response) {
                    hideProgress();
                    $button.prop('disabled', false);

                    if (response.success) {
                        showMessage(response.data.message, 'success');
                        updateStatus(false, 0);
                    } else {
                        showMessage(response.data.message, 'error');
                    }
                },
                error: function() {
                    hideProgress();
                    $button.prop('disabled', false);
                    showMessage('<?php _e('An error occurred. Please try again.', 'roihin-crystal'); ?>', 'error');
                }
            });
        });
    });
    </script>
    <?php
}
